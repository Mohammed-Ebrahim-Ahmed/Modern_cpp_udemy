#pragma once
#include "Account.h"
void Transact(Account *pAccount);
